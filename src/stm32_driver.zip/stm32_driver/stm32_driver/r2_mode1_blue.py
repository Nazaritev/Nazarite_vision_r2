#!/usr/bin/env python3
import sys
import threading
from pathlib import Path

package_root = Path(__file__).resolve().parents[1]
if str(package_root) not in sys.path:
    sys.path.insert(0, str(package_root))

import rclpy

from stm32_driver.r2_mode1 import ChassisMode, NavTarget, R2_mode1, RobotState


class R2_mode1_blue(R2_mode1):
    BLUE_DEFAULT_START_GRAB_INDEX = 3
    BLUE_CMD1_TO_CMD7_DELAY = 1.0
    BLUE_POST_BARCODE_CMD8_DELAY = 1.2
    BLUE_POST_BARCODE_CMD3_DELAY = 0.5

    def __init__(self, node_name: str = "r2_mode1_blue"):
        self._blue_initial_navigation_deferred = True
        try:
            super().__init__(node_name=node_name)
        except TypeError:
            super().__init__()

        self.apply_blue_mirror_config()
        self.open_loop_grab_depart_delay = self.BLUE_CMD1_TO_CMD7_DELAY
        self._blue_initial_navigation_deferred = False
        self.start_initial_navigation()

    def start_initial_navigation(self):
        if getattr(self, "_blue_initial_navigation_deferred", False):
            return
        with self.lock:
            if self.initial_navigation_started:
                return
            self.initial_navigation_started = True
            start_index = self.resolve_start_grab_index()
            self.navigate_to_grab_point(start_index)
            self.send_serial("8")
            self.stop_serial("8")
        self.get_logger().info(
            f"蓝方启动即发布第一个导航点，目标抓取点 {start_index}，并同步发送命令8（无需回包）"
        )

    def resolve_start_grab_index(self) -> int:
        index = super().resolve_start_grab_index()
        if (
            index == 0
            and len(self.grab_points) > self.BLUE_DEFAULT_START_GRAB_INDEX
        ):
            default_point = self.grab_points[self.BLUE_DEFAULT_START_GRAB_INDEX]
            self.get_logger().info(
                "蓝方起始抓取点使用默认索引 "
                f"{self.BLUE_DEFAULT_START_GRAB_INDEX}: "
                f"({default_point.x:.2f}, {default_point.y:.2f}, "
                f"{default_point.z:.1f}, {default_point.yaw:.1f})"
            )
            return self.BLUE_DEFAULT_START_GRAB_INDEX
        return index

    def apply_blue_mirror_config(self):
        original_align_target_y = float(self.align_target_y)
        self.align_target_y = -original_align_target_y
        self.mirror_goal_points()
        self.get_logger().info(
            "蓝方镜像模式已启用："
            f"align_target_y {original_align_target_y:.3f} -> {self.align_target_y:.3f}，"
            "预设点位 y/yaw 与左右自旋底盘模式已反转"
        )

    def mirror_goal_points(self):
        for point in self.grab_points:
            point.y = -point.y
            point.yaw = -point.yaw
        for point in self.shift_points:
            point.y = -point.y
            point.yaw = -point.yaw
        self.final_point.y = -self.final_point.y
        self.final_point.yaw = -self.final_point.yaw

    def get_final_result_cmd(self) -> str:
        return "9"

    def navigate_to_shift_point(self, index: int):
        self.cancel_pre_grab_open_loop_timer_locked()
        self.active_nav_target = NavTarget.NONE
        self.active_nav_index = None
        self.current_state = RobotState.WAITING_SHIFT_PREPARE_RESULT
        self.set_chassis_mode(
            ChassisMode.HOLD,
            f"蓝方抓取完成，跳过平移点 {index}，等待电控命令7流程完成",
        )
        self.send_serial("7")
        self.get_logger().info(
            f"蓝方抓取点 {index} 抓取后跳过平移点，已发送命令7；"
            "等待回包后进入 TF 对位和扫码"
        )

    def schedule_shift_return_after_barcode(
        self,
        reason: str,
        force_final: bool = False,
        action: str = "final",
    ):
        self.pending_shift_return_reason = reason
        self.pending_shift_return_force_final = force_final
        self.pending_shift_return_index = self.point_index
        self.pending_shift_return_action = action
        self.current_state = (
            RobotState.WAITING_SHIFT_RETURN_RESULT
            if action == "retry_next"
            else RobotState.WAITING_FINAL_RESULT
        )
        self.set_chassis_mode(
            ChassisMode.HOLD,
            "蓝方扫码完成，跳过扫码后 odom 0.3m 移动",
        )
        self.send_serial("8")
        self.stop_serial("8")
        threading.Timer(
            self.BLUE_POST_BARCODE_CMD8_DELAY,
            self.finish_post_barcode_after_cmd8,
            args=(reason, action),
        ).start()

    def finish_post_barcode_after_cmd8(self, reason: str, action: str):
        with self.lock:
            if self.current_state not in (
                RobotState.WAITING_SHIFT_RETURN_RESULT,
                RobotState.WAITING_FINAL_RESULT,
            ):
                return

        self.send_serial("3")
        self.stop_serial("3")
        threading.Timer(
            self.BLUE_POST_BARCODE_CMD3_DELAY,
            self.finish_post_barcode_after_cmd3,
            args=(reason, action),
        ).start()

    def finish_post_barcode_after_cmd3(self, reason: str, action: str):
        with self.lock:
            if self.current_state not in (
                RobotState.WAITING_SHIFT_RETURN_RESULT,
                RobotState.WAITING_FINAL_RESULT,
            ):
                return

        if action == "retry_next":
            self.send_serial("4")
            self.get_logger().info(
                f"{reason}，蓝方已跳过扫码后 0.3m 移动；"
                f"命令8后延时 {self.BLUE_POST_BARCODE_CMD8_DELAY:.1f}s，"
                f"命令3后延时 {self.BLUE_POST_BARCODE_CMD3_DELAY:.1f}s，"
                "已发送命令4，等待命令4回包后前往下一个抓取点"
            )
            return

        final_cmd = self.get_final_result_cmd()
        self.send_serial(final_cmd)
        self.publish_mode2_and_release_hold(
            f"蓝方最终命令{final_cmd}已发送，释放底盘给后续导航",
        )
        self.get_logger().info(
            f"{reason}，蓝方已跳过扫码后 0.3m 移动；"
            f"命令8后延时 {self.BLUE_POST_BARCODE_CMD8_DELAY:.1f}s，"
            f"命令3后延时 {self.BLUE_POST_BARCODE_CMD3_DELAY:.1f}s，"
            f"已发送最终命令{final_cmd}，底盘已切回 NAVIGATION，"
            "已发布 /mode=2，等待最终回包后结束"
        )

    @staticmethod
    def swap_spin_mode(mode: ChassisMode) -> ChassisMode:
        if mode == ChassisMode.SPIN_FORWARD:
            return ChassisMode.SPIN_BACKWARD
        if mode == ChassisMode.SPIN_BACKWARD:
            return ChassisMode.SPIN_FORWARD
        return mode

    def set_chassis_mode(self, mode: ChassisMode, reason: str = ""):
        super().set_chassis_mode(self.swap_spin_mode(mode), reason)


def main():
    rclpy.init(args=sys.argv)
    node = None
    try:
        node = R2_mode1_blue()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
