#!/usr/bin/env python3
import math
import sys
import threading
from pathlib import Path

package_root = Path(__file__).resolve().parents[1]
if str(package_root) not in sys.path:
    sys.path.insert(0, str(package_root))

import rclpy
from geometry_msgs.msg import Twist
from std_msgs.msg import Int32

from stm32_driver.r2_mode1 import (
    SERIAL_COMMANDS,
    ChassisMode,
    Point3d,
    RobotState,
)
from stm32_driver.r1_mode1_challenge_red import R1Mode1ChallengeRed


class R1Mode1ChallengeRedTest(R1Mode1ChallengeRed):
    CHALLENGE_BARCODE_POINTS = (
        Point3d(-0.80, 0.21, 0.0, 0.0),
    )
    CHALLENGE_RELATIVE_OFFSETS = {}
    CONTACT_APPROACH_MODE_VALUE = 4
    MODE2_AFTER_CMD9_REPLY_COUNT = 3

    def __init__(self, node_name: str = "r1_mode1_challenge_red_test"):
        self._direct_contact_active = False
        self._direct_contact_timer = None
        self._direct_contact_start_time = None
        self._direct_contact_start_pose = None
        self._cmd9_reply_count = 0
        super().__init__(node_name=node_name)

        self.declare_parameter("contact_approach_cmd_vel_topic", "/contact_cmd_vel")
        self.declare_parameter("contact_approach_speed_x", -0.40)
        self.declare_parameter("contact_approach_timeout_sec", 3.0)
        self.declare_parameter("contact_approach_max_distance", 0.25)
        self.declare_parameter("contact_approach_command_period_sec", 0.05)

        self.contact_approach_cmd_vel_topic = str(
            self.get_parameter("contact_approach_cmd_vel_topic").value
        ).strip() or "/contact_cmd_vel"
        self.contact_approach_speed_x = float(
            self.get_parameter("contact_approach_speed_x").value
        )
        if self.contact_approach_speed_x > 0.0:
            self.get_logger().warn(
                f"contact_approach_speed_x={self.contact_approach_speed_x:.3f} 为正，"
                "固定顶靠只允许后退，自动改为负值"
            )
            self.contact_approach_speed_x = -self.contact_approach_speed_x
        self.contact_approach_timeout_sec = max(
            0.1, float(self.get_parameter("contact_approach_timeout_sec").value)
        )
        self.contact_approach_max_distance = max(
            0.0, float(self.get_parameter("contact_approach_max_distance").value)
        )
        self.contact_approach_command_period_sec = max(
            0.02, float(self.get_parameter("contact_approach_command_period_sec").value)
        )
        self.direct_contact_cmd_pub = self.create_publisher(
            Twist,
            self.contact_approach_cmd_vel_topic,
            10,
        )
        self.get_logger().info(
            "红方挑战测试模式已启用：仅保留第 1 个导航点；"
            "第 1/2 次命令9回包后直接进入固定后退顶靠；"
            f"第 {self.MODE2_AFTER_CMD9_REPLY_COUNT} 次命令9回包后发布 /mode=2 "
            f"topic={self.contact_approach_cmd_vel_topic} "
            f"speed_x={self.contact_approach_speed_x:.3f}m/s "
            f"timeout={self.contact_approach_timeout_sec:.2f}s "
            f"max_distance={self.contact_approach_max_distance:.3f}m"
        )

    def handle_serial_frame(self, frame: dict):
        with self.lock:
            if (
                self._challenge_after_cmd9_action == "finish"
                and frame["mode"] == SERIAL_COMMANDS["9"]["mode"]
                and frame["task_complete"] == 1
            ):
                self.stop_serial("9")
                self._challenge_after_cmd9_action = None
                self._challenge_phase = None
                self._cmd9_reply_count += 1
                if self._cmd9_reply_count >= self.MODE2_AFTER_CMD9_REPLY_COUNT:
                    self.publish_mode2_after_third_cmd9_reply()
                    return

                self.start_direct_contact_approach()
                self.get_logger().info(
                    f"红方挑战测试：收到第 {self._cmd9_reply_count}/"
                    f"{self.MODE2_AFTER_CMD9_REPLY_COUNT} 次命令9完成回包，"
                    "直接触发固定后退顶靠"
                )
                return

        super().handle_serial_frame(frame)

    def start_direct_contact_approach(self):
        if self._direct_contact_active:
            return

        self._direct_contact_active = True
        self._challenge_phase = "direct_contact_approach"
        self.current_state = RobotState.WAITING_SHIFT_RETURN_DELAY
        self._direct_contact_start_time = self.get_clock().now().nanoseconds / 1e9
        self._direct_contact_start_pose = self.current_odom_pose
        self.mode_pub.publish(Int32(data=self.CONTACT_APPROACH_MODE_VALUE))
        self.publish_direct_contact_velocity()
        self._direct_contact_timer = self.create_timer(
            self.contact_approach_command_period_sec,
            self.handle_direct_contact_approach,
        )
        self.get_logger().warn(
            "红方挑战测试：已切换底盘 CONTACT_APPROACH 并开始发布固定后退顶靠速度"
        )

    def publish_direct_contact_velocity(self):
        msg = Twist()
        msg.linear.x = self.contact_approach_speed_x
        self.direct_contact_cmd_pub.publish(msg)

    def publish_direct_contact_stop(self):
        msg = Twist()
        for _ in range(20):
            self.direct_contact_cmd_pub.publish(msg)

    def get_direct_contact_distance(self):
        if self._direct_contact_start_pose is None or self.current_odom_pose is None:
            return None

        return math.hypot(
            self.current_odom_pose.x - self._direct_contact_start_pose.x,
            self.current_odom_pose.y - self._direct_contact_start_pose.y,
        )

    def handle_direct_contact_approach(self):
        if not self._direct_contact_active:
            return

        now_sec = self.get_clock().now().nanoseconds / 1e9
        elapsed = now_sec - self._direct_contact_start_time
        traveled = self.get_direct_contact_distance()
        if elapsed >= self.contact_approach_timeout_sec:
            self.finish_direct_contact_approach(
                f"固定后退顶靠超时 {elapsed:.2f}s"
            )
            return

        if (
            traveled is not None
            and self.contact_approach_max_distance > 0.0
            and traveled >= self.contact_approach_max_distance
        ):
            self.finish_direct_contact_approach(
                f"固定后退顶靠距离达到 {traveled:.3f}m"
            )
            return

        self.publish_direct_contact_velocity()

    def finish_direct_contact_approach(self, reason: str):
        if not self._direct_contact_active:
            return

        self._direct_contact_active = False
        if self._direct_contact_timer is not None:
            self._direct_contact_timer.cancel()
            self._direct_contact_timer = None
        self.publish_direct_contact_stop()
        self.mode_pub.publish(Int32(data=int(ChassisMode.HOLD)))
        self.current_chassis_mode = ChassisMode.HOLD
        self.get_logger().warn(f"红方挑战测试：{reason}，已停车并切回 HOLD，进入正常夹取流程")
        self.start_post_contact_grab()

    def start_post_contact_grab(self):
        self._challenge_phase = "waiting_challenge_cmd1_delay"
        self.current_state = RobotState.WAITING_SHIFT_PREPARE_RESULT
        point_number = self._cmd9_reply_count + 1
        reason = f"红方挑战测试第 {point_number} 轮顶靠完成"
        self.set_chassis_mode(
            ChassisMode.HOLD,
            f"{reason}，先执行命令1再延时发送命令7",
        )
        self.send_serial("1")
        self.stop_serial("1")
        threading.Timer(
            self.CHALLENGE_CMD1_TO_CMD7_DELAY,
            self.send_challenge_cmd7_after_cmd1_delay,
            args=(reason, point_number),
        ).start()
        self.get_logger().info(
            f"红方挑战测试：顶靠结束后已发送命令1；"
            f"{self.CHALLENGE_CMD1_TO_CMD7_DELAY:.2f}s 后发送命令7，"
            "随后进入 TF 对位和扫码"
        )

    def publish_mode2_after_third_cmd9_reply(self):
        self.current_state = RobotState.FINISHED
        self.publish_mode2_and_release_hold(
            "红方挑战测试：第三次命令9回包完成，发布 /mode=2"
        )
        self.stop_serial_reader_after_mode2()
        self.get_logger().info(
            "红方挑战测试：第三次收到命令9回包，已发布 /mode=2，状态 -> FINISHED"
        )


def main():
    rclpy.init(args=sys.argv)
    node = None
    try:
        node = R1Mode1ChallengeRedTest()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
