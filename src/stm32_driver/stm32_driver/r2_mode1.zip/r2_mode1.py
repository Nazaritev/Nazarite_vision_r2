#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy, HistoryPolicy, qos_profile_sensor_data
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from std_msgs.msg import Int32, Bool, String, Float32
import tf2_ros
from tf2_ros import TransformException
import serial
import math
import time
import threading
import sys
import struct
from enum import Enum, IntEnum, auto

CHASSIS_MODE_TOPIC = "/chassis_mode"


class RobotState(Enum):
    INIT = auto()               # 初始化状态
    NAVIGATING = auto()         # 导航移动中
    STABILIZING = auto()        # 到达目标点，等待稳定
    DETECTING = auto()          # 检测物体（颜色+深度）
    WAITING_GRAB_RESULT = auto()  # 已发送1抓取，等待抓取结果判定
    SPINNING_FORWARD = auto()   # 到达平移点后正向自旋 180 度
    ALIGNING_TF = auto()        # 正向自旋结束后等待 TF 对位
    WAITING_BARCODE = auto()    # 已发送2，等待二维码(100/200)
    SPINNING_BACK = auto()      # 扫码完成后反向自旋回原朝向
    WAITING_FINAL_RESULT = auto()  # 到达最终点后已发送6，等待电控完成回包
    FINISHED = auto()           # 最终流程完成


class NavTarget(Enum):
    NONE = auto()
    GRAB_POINT = auto()
    SHIFT_POINT = auto()
    FINAL_POINT = auto()


class ChassisMode(IntEnum):
    NAVIGATION = 0
    SPIN_FORWARD = 1
    HOLD = 2
    SPIN_BACKWARD = 3


class Point3d:
    def __init__(self, x_, y_, z_, yaw_=0.0):
        self.x = x_
        self.y = y_
        self.z = z_
        self.yaw = yaw_


FRAME_HEADER = 0xAA
FRAME_TAIL = 0x55
FRAME_PAYLOAD_LENGTH = 7
FRAME_LENGTH = 11

SERIAL_COMMANDS = {
    "1": {"region": 0x01, "mode": 0x01, "need_return": 0, "data": 0},
    "2": {"region": 0x01, "mode": 0x02, "need_return": 0, "data": 0},
    "3": {"region": 0x01, "mode": 0x03, "need_return": 1, "data": 0},
    "4": {"region": 0x01, "mode": 0x04, "need_return": 0, "data": 0},
    "5": {"region": 0x01, "mode": 0x05, "need_return": 0, "data": 0},
    "6": {"region": 0x01, "mode": 0x06, "need_return": 1, "data": 0},
}


def modbus_crc16(data: bytes) -> bytes:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x0001:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc.to_bytes(2, byteorder="little")


def build_vision_frame(region: int, mode: int, need_return: int, data_value: int = 0) -> bytes:
    data_bytes = struct.pack("<h", data_value)
    payload = bytes([region, mode, need_return]) + data_bytes + b"\x00\x00"
    crc = modbus_crc16(payload)
    return bytes([FRAME_HEADER]) + payload + crc + bytes([FRAME_TAIL])


def parse_vision_frame(frame: bytes) -> dict | None:
    if len(frame) != FRAME_LENGTH:
        return None
    if frame[0] != FRAME_HEADER or frame[-1] != FRAME_TAIL:
        return None

    payload = frame[1:1 + FRAME_PAYLOAD_LENGTH]
    crc_received = frame[1 + FRAME_PAYLOAD_LENGTH:1 + FRAME_PAYLOAD_LENGTH + 2]
    crc_calc = modbus_crc16(payload)

    return {
        "region": payload[0],
        "mode": payload[1],
        "task_complete": payload[2],
        "data": struct.unpack("<h", payload[3:5])[0],
        "reserve": payload[5:7],
        "crc_ok": crc_calc == crc_received,
        "raw": frame.hex(),
    }


class R2_mode1(Node):
    def __init__(self, node_name: str = "r2_mode1"):
        super().__init__(node_name)
        qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        selector_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
        )

        # 参数 
        self.declare_parameter('target_tag_frame', 'base')
        self.declare_parameter('reference_frame', 'camera_link')
        self.declare_parameter('align_target_y', 0.0) #可改
        self.declare_parameter('align_tolerance', 0.01)
        self.declare_parameter('stabilization_time', 0.5)
        self.declare_parameter('spin_target_angle_deg', 180.0)
        self.declare_parameter('spin_angle_tolerance_deg', 2.0)
        self.declare_parameter('final_spin_angle_deg', 90.0)
        self.declare_parameter('spin_control_mode', 'serial4')
        self.declare_parameter('spin_angle_source', 'imu')
        self.declare_parameter('spin_imu_topic', '/livox/imu')
        self.declare_parameter('spin_imu_timeout', 0.5)
        self.declare_parameter('spin_auto_fallback_to_odom', True)
        self.declare_parameter('grab_xy_goal_tolerance', 0.005)
        self.declare_parameter('shift_xy_goal_tolerance', 0.05)
        self.declare_parameter('final_xy_goal_tolerance', 0.05)
        self.declare_parameter('grab_goal_checker_id', 'grab_goal_checker')
        self.declare_parameter('shift_goal_checker_id', 'shift_goal_checker')
        self.declare_parameter('final_goal_checker_id', 'pose_goal_checker')
        self.declare_parameter('goal_checker_selector_topic', '/goal_checker_selector')
        self.declare_parameter('wait_for_vision_before_start', True)
        self.declare_parameter('vision_startup_timeout', 20.0)
        self.target_tag_frame = self.get_parameter('target_tag_frame').value
        self.reference_frame = self.get_parameter('reference_frame').value
        self.align_target_y = self.get_parameter('align_target_y').value
        self.align_tolerance = self.get_parameter('align_tolerance').value
        self.stabilization_time = self.get_parameter('stabilization_time').value
        self.spin_target_angle = math.radians(self.get_parameter('spin_target_angle_deg').value)
        self.spin_angle_tolerance = math.radians(self.get_parameter('spin_angle_tolerance_deg').value)
        self.final_spin_target_angle = math.radians(self.get_parameter('final_spin_angle_deg').value)
        self.spin_control_mode = str(self.get_parameter('spin_control_mode').value).strip().lower()
        if self.spin_control_mode not in ("serial4", "local"):
            self.get_logger().warn(
                f"未知 spin_control_mode={self.spin_control_mode}，回退到 serial4"
            )
            self.spin_control_mode = "serial4"
        self.spin_angle_source = str(self.get_parameter('spin_angle_source').value).strip().lower()
        if self.spin_angle_source not in ("imu", "odom"):
            self.get_logger().warn(
                f"未知 spin_angle_source={self.spin_angle_source}，回退到 odom"
            )
            self.spin_angle_source = "odom"
        self.spin_imu_topic = self.get_parameter('spin_imu_topic').value
        self.spin_imu_timeout = float(self.get_parameter('spin_imu_timeout').value)
        self.spin_auto_fallback_to_odom = bool(self.get_parameter('spin_auto_fallback_to_odom').value)
        self.grab_xy_goal_tolerance = float(self.get_parameter('grab_xy_goal_tolerance').value)
        self.shift_xy_goal_tolerance = float(self.get_parameter('shift_xy_goal_tolerance').value)
        self.final_xy_goal_tolerance = float(self.get_parameter('final_xy_goal_tolerance').value)
        self.grab_goal_checker_id = str(self.get_parameter('grab_goal_checker_id').value).strip()
        self.shift_goal_checker_id = str(self.get_parameter('shift_goal_checker_id').value).strip()
        self.final_goal_checker_id = str(self.get_parameter('final_goal_checker_id').value).strip()
        self.goal_checker_selector_topic = self.get_parameter('goal_checker_selector_topic').value
        self.wait_for_vision_before_start = bool(self.get_parameter('wait_for_vision_before_start').value)
        self.vision_startup_timeout = float(self.get_parameter('vision_startup_timeout').value)

        # 串口初始化
        self.declare_parameter('serial_port', '/dev/ttyUSB1')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('timeout', 1.0)
        # 保留旧参数兼容启动配置；当前版本不再使用重复发送。
        self.declare_parameter('serial_repeat_interval', 1.0)
        serial_port = self.get_parameter('serial_port').value
        baudrate = self.get_parameter('baudrate').value
        timeout = self.get_parameter('timeout').value
        self.serial = None
        self.serial_rx_buffer = bytearray()
        self.node_running = True
        # 仅记录最近一次发给电控、尚未被状态机清理的命令；不再用于重复发送。
        self.active_serial_cmd = None
        try:
            self.serial = serial.Serial(
                port=serial_port,
                baudrate=baudrate,
                timeout=timeout,
                write_timeout=1.0,
            )
            self.get_logger().info(f'串口连接成功: {serial_port} | 波特率: {baudrate}')
        except Exception as e:
            self.get_logger().error(f'串口打开失败: {str(e)}')

        self.grab_points = [
            Point3d(-0.85, 0.75, 0.0, 0.0),
            Point3d(-0.85, 0.95, 0.0, 0.0),
            Point3d(-0.85, 1.15, 0.0, 0.0),
        ]
        self.shift_points = [
            Point3d(-0.60, 0.75, 0.0, 0.0),
            Point3d(-0.60, 0.95, 0.0, 0.0),
            Point3d(-0.60, 1.15, 0.0, 0.0),
        ]
        self.final_point = Point3d(1.85, 1.4, 0.0, 0.0)
        self.point_index = 0
        self.grab_count = 0
        self.max_grab_count = 2
        self.active_nav_target = NavTarget.NONE
        self.active_nav_index = None

        # --- 核心改变：引入状态机 ---
        self.current_state = RobotState.INIT
        self.special_barcode_triggered = False
        self.current_chassis_mode = ChassisMode.NAVIGATION
        self.initial_navigation_started = False
        self.current_goal_checker_id = None
        self.startup_wait_cycles = 0
        self.startup_wait_start_time = time.monotonic()

        # 抓取反馈专用变量（独立于主状态机的并行检测）
        self.checking_grab_feedback = False
        self.pre_grab_depth = 0.0
        self.current_depth = 0.0
        self.depth_sample_received = False
        self.object_present = False
        self.object_detected_rx_count = 0
        self.object_depth_rx_count = 0
        self.grab_start_time = 0.0
        self.grab_check_delay = 1.25
        self.grab_depth_tolerance = 0.05
        self.current_yaw = None
        self.spin_start_yaw = None
        self.last_spin_yaw = None
        self.last_imu_rx_time = None
        self.imu_last_sample_time = None
        self.imu_integrated_yaw = 0.0
        self.imu_start_frame_locked = False
        self.spin_accumulated_yaw = 0.0
        self.spin_source_in_use = "odom"
        self.pending_post_spin_reason = None
        self.pending_post_spin_force_final = False
        self.pending_post_spin_send_cmd3 = True
        self.active_spin_target_angle = self.spin_target_angle

        self.lock = threading.RLock()

        # ROS 接口
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.tf_timer = self.create_timer(0.1, self.tf_check_loop)
        self.nav_sub = self.create_subscription(Bool, "/agent/arrival_status", self.nav_callback, qos)
        self.odom_sub = self.create_subscription(Odometry, "/Odometry", self.odom_callback, qos)
        self.imu_sub = None
        if self.spin_angle_source == "imu":
            self.imu_sub = self.create_subscription(Imu, self.spin_imu_topic, self.imu_callback, qos)
        self.mode_pub = self.create_publisher(Int32, CHASSIS_MODE_TOPIC, qos)
        self.external_mode_pub = self.create_publisher(Int32, "/mode", qos)
        self.goal_pub = self.create_publisher(PoseStamped, "goal_pose", qos)
        self.barcode_sub = self.create_subscription(String, "/barcode", self.barcode_callback, 10)
        self.goal_checker_selector_pub = self.create_publisher(
            String,
            self.goal_checker_selector_topic,
            selector_qos,
        )
        # 颜色+深度检测订阅
        self.object_sub = self.create_subscription(
            Bool, "/object_detected", self.object_status_callback, qos_profile_sensor_data
        )
        self.depth_sub = self.create_subscription(
            Float32, "/object_depth", self.object_depth_callback, qos_profile_sensor_data
        )
        self.grab_feedback_timer = self.create_timer(0.1, self.grab_feedback_timer_callback)
        self.sensor_topic_debug_timer = self.create_timer(2.0, self.sensor_topic_debug_timer_callback)
        self.startup_timer = self.create_timer(0.5, self.try_start_initial_navigation)

        # 串口线程
        self.serial_thread = threading.Thread(target=self.listen_stm32_data, daemon=True)
        self.serial_thread.start()
        self.get_logger().info(
            "R2_mode1 初始化完成（Enum 状态机重构版），等待视觉首帧后发送首个导航点"
        )
        self.get_logger().info(f"自旋控制模式: {self.spin_control_mode}")
        self.get_logger().info(
            f"自旋角度源配置: {self.describe_spin_source(self.spin_angle_source)}"
            f" | IMU 超时回退 odom={self.spin_auto_fallback_to_odom}"
        )
        self.get_logger().info("串口命令发送模式: 单次下发（不重复发送）")

    def try_start_initial_navigation(self):
        if self.initial_navigation_started:
            self.startup_timer.cancel()
            return

        if self.wait_for_vision_before_start:
            vision_ready = self.object_detected_rx_count > 0 and self.object_depth_rx_count > 0
            if not vision_ready:
                self.startup_wait_cycles += 1
                elapsed = time.monotonic() - self.startup_wait_start_time
                if self.vision_startup_timeout <= 0.0 or elapsed < self.vision_startup_timeout:
                    if self.startup_wait_cycles % 4 == 0:
                        self.get_logger().info(
                            "等待视觉首帧（含远端 DDS 发现）... "
                            f"/object_detected={self.object_detected_rx_count}, "
                            f"/object_depth={self.object_depth_rx_count}, "
                            f"elapsed={elapsed:.1f}s/"
                            f"{'inf' if self.vision_startup_timeout <= 0.0 else f'{self.vision_startup_timeout:.1f}s'}"
                        )
                    return
                self.get_logger().warn(
                    "视觉首帧等待超时，仍按原流程启动导航；"
                    "远端 DDS 视觉节点可能尚未完成发现 | "
                    f"/object_detected={self.object_detected_rx_count}, "
                    f"/object_depth={self.object_depth_rx_count}, "
                    f"timeout={self.vision_startup_timeout:.1f}s"
                )

        self.startup_timer.cancel()
        self.start_initial_navigation()

    def start_initial_navigation(self):
        with self.lock:
            if self.initial_navigation_started:
                return
            self.initial_navigation_started = True
            self.navigate_to_grab_point(0)
        self.get_logger().info("启动即发布第一个导航点")

    @staticmethod
    def describe_qos_policy(policy) -> str:
        return getattr(policy, "name", str(policy))

    def log_sensor_topic_debug(self, reason: str):
        for topic_name, rx_count in (
            ("/object_detected", self.object_detected_rx_count),
            ("/object_depth", self.object_depth_rx_count),
        ):
            pub_count = self.count_publishers(topic_name)
            infos = self.get_publishers_info_by_topic(topic_name)
            self.get_logger().info(
                f"[视觉订阅自检] {reason} | topic={topic_name} | rx_count={rx_count} | publishers={pub_count}"
            )
            for info in infos:
                qos = info.qos_profile
                self.get_logger().info(
                    "[视觉订阅自检] "
                    f"topic={topic_name} | pub_node={info.node_namespace}/{info.node_name} "
                    f"| type={info.topic_type} | reliability={self.describe_qos_policy(qos.reliability)} "
                    f"| durability={self.describe_qos_policy(qos.durability)} | depth={qos.depth}"
                )

    def sensor_topic_debug_timer_callback(self):
        with self.lock:
            if self.object_detected_rx_count > 0 and self.object_depth_rx_count > 0:
                self.sensor_topic_debug_timer.cancel()
                return
            self.log_sensor_topic_debug("启动后仍未收到完整视觉数据，可能远端 DDS 视觉节点尚未发现")

    def select_goal_checker_for_target(self, checker_id: str, target_name: str):
        checker_id = checker_id.strip()
        if not checker_id:
            self.get_logger().warn(f"目标={target_name} 未配置 goal checker，沿用当前设置")
            return
        if self.current_goal_checker_id == checker_id:
            return
        self.goal_checker_selector_pub.publish(String(data=checker_id))
        self.current_goal_checker_id = checker_id
        self.get_logger().info(f"已切换 goal checker -> {checker_id} | 目标={target_name}")

    def navigate_to_grab_point(self, index: int):
        self.point_index = index
        self.active_nav_target = NavTarget.GRAB_POINT
        self.active_nav_index = index
        self.current_state = RobotState.NAVIGATING
        self.select_goal_checker_for_target(self.grab_goal_checker_id, f"抓取点 {index}")
        self.set_chassis_mode(ChassisMode.NAVIGATION, f"准备前往抓取点 {index}")
        self.publish_goal(self.grab_points[index], f"抓取点 {index}")

    def navigate_to_shift_point(self, index: int):
        self.active_nav_target = NavTarget.SHIFT_POINT
        self.active_nav_index = index
        self.current_state = RobotState.NAVIGATING
        self.select_goal_checker_for_target(self.shift_goal_checker_id, f"平移点 {index}")
        self.set_chassis_mode(ChassisMode.NAVIGATION, f"抓取成功，前往平移点 {index}")
        self.publish_goal(self.shift_points[index], f"平移点 {index}")

    def navigate_to_final_point(self):
        self.active_nav_target = NavTarget.FINAL_POINT
        self.active_nav_index = None
        self.current_state = RobotState.NAVIGATING
        self.select_goal_checker_for_target(self.final_goal_checker_id, "最终点")
        self.set_chassis_mode(ChassisMode.NAVIGATION, "准备前往最终点")
        self.publish_goal(self.final_point, "最终点")

    def set_chassis_mode(self, mode: ChassisMode, reason: str = ""):
        self.mode_pub.publish(Int32(data=int(mode)))
        if self.current_chassis_mode != mode:
            self.current_chassis_mode = mode
            suffix = f" | {reason}" if reason else ""
            self.get_logger().info(f"切换底盘模式 -> {mode.name}{suffix}")

    def reset_spin_tracking(self):
        self.spin_start_yaw = None
        self.last_spin_yaw = None
        self.spin_accumulated_yaw = 0.0

    def is_spinning_state(self) -> bool:
        return self.current_state in (
            RobotState.SPINNING_FORWARD,
            RobotState.SPINNING_BACK,
        )

    def describe_spin_source(self, source: str) -> str:
        if source == "imu":
            return f"IMU({self.spin_imu_topic})"
        return "ODOM(/Odometry)"

    def select_spin_source(self) -> str:
        if self.spin_angle_source != "imu":
            return "odom"

        if not self.spin_auto_fallback_to_odom:
            return "imu"

        if self.last_imu_rx_time is None:
            self.get_logger().warn("未收到 IMU 数据，本轮自旋回退到 ODOM")
            return "odom"

        imu_age = time.monotonic() - self.last_imu_rx_time
        if imu_age > self.spin_imu_timeout:
            self.get_logger().warn(
                f"IMU 数据超时 {imu_age:.2f}s，本轮自旋回退到 ODOM"
            )
            return "odom"

        return "imu"

    def prepare_spin_tracking(self) -> str:
        self.reset_spin_tracking()
        self.spin_source_in_use = self.select_spin_source()
        source_desc = self.describe_spin_source(self.spin_source_in_use)
        if self.spin_source_in_use == "imu" and self.imu_start_frame_locked:
            self.spin_start_yaw = self.imu_integrated_yaw
            self.last_spin_yaw = self.imu_integrated_yaw
            self.get_logger().info(
                "使用启动时首帧 IMU 作为全局零点，"
                f"当前累计角度 {math.degrees(self.imu_integrated_yaw):.1f} deg，作为本轮自旋起点"
            )
        self.get_logger().info(f"自旋角度累计源 -> {source_desc}")
        return source_desc

    def maybe_fallback_spin_source_to_odom(self, current_odom_yaw: float) -> bool:
        if self.spin_source_in_use != "imu" or not self.spin_auto_fallback_to_odom:
            return False

        if self.last_imu_rx_time is None:
            imu_age = float("inf")
        else:
            imu_age = time.monotonic() - self.last_imu_rx_time

        if imu_age <= self.spin_imu_timeout:
            return False

        self.spin_source_in_use = "odom"
        self.last_spin_yaw = current_odom_yaw
        self.get_logger().warn(
            f"自旋过程中 IMU 数据超时 {imu_age:.2f}s，回退到 ODOM 继续累计角度"
        )
        return True

    def update_spin_with_yaw(self, yaw: float, source_desc: str):
        if self.spin_start_yaw is None:
            self.spin_start_yaw = yaw
            self.last_spin_yaw = yaw
            if self.spin_accumulated_yaw > 0.0:
                self.get_logger().info(
                    f"已切换到 {source_desc}，保留已累计角度 {math.degrees(self.spin_accumulated_yaw):.1f} deg"
                )
            else:
                self.get_logger().info(f"已锁定 {source_desc} 自旋起始朝向，开始累计旋转角度")
            return

        delta_yaw = abs(self.normalize_angle(yaw - self.last_spin_yaw))
        self.last_spin_yaw = yaw
        if delta_yaw < 1e-4:
            return

        self.spin_accumulated_yaw += delta_yaw
        if self.spin_accumulated_yaw >= max(0.0, self.active_spin_target_angle - self.spin_angle_tolerance):
            self.finish_spin()

    def update_spin_with_imu(self):
        if self.spin_start_yaw is None:
            self.spin_start_yaw = self.imu_integrated_yaw
            self.last_spin_yaw = self.imu_integrated_yaw
            self.get_logger().info(
                "IMU 自旋起点尚未就绪，已使用当前累计 IMU 角度补锁起点"
            )
            return

        delta_yaw = abs(self.imu_integrated_yaw - self.last_spin_yaw)
        self.last_spin_yaw = self.imu_integrated_yaw
        if delta_yaw < 1e-4:
            return

        self.spin_accumulated_yaw += delta_yaw
        if self.spin_accumulated_yaw >= max(0.0, self.active_spin_target_angle - self.spin_angle_tolerance):
            self.finish_spin()

    def start_spin_mode(self, shift_index: int | None):
        if self.spin_control_mode == "local":
            self.current_state = RobotState.SPINNING_FORWARD
            self.active_spin_target_angle = self.spin_target_angle
            source_desc = self.prepare_spin_tracking()
            self.set_chassis_mode(ChassisMode.SPIN_FORWARD, f"到达平移点 {shift_index}，开始自旋 180 度")
            self.get_logger().info(f"平移点 {shift_index} 已到达，等待 {source_desc} 累计旋转角度")
            return

        self.set_chassis_mode(ChassisMode.HOLD, f"到达平移点 {shift_index}，串口模式下由电控自旋")
        self.send_serial("4")
        self.current_state = RobotState.ALIGNING_TF
        self.get_logger().info(
            f"平移点 {shift_index} 已到达，已发送命令4触发电控自旋；"
            "ROS 不再发布自旋底盘模式，不等待回包，直接进入 TF 对位与扫码流程"
        )

    def start_spin_back(self, reason: str, force_final: bool = False, send_cmd3_after_spin: bool = True):
        self.pending_post_spin_reason = reason
        self.pending_post_spin_force_final = force_final
        self.pending_post_spin_send_cmd3 = send_cmd3_after_spin
        if self.spin_control_mode == "local":
            self.current_state = RobotState.SPINNING_BACK
            self.active_spin_target_angle = self.spin_target_angle
            source_desc = self.prepare_spin_tracking()
            self.set_chassis_mode(ChassisMode.SPIN_BACKWARD, "扫码完成，开始反向自旋回原朝向")
            self.get_logger().info(
                f"扫码阶段结束，开始反向自旋 180 度，使用 {source_desc} 回正后再发布下一个导航点"
            )
            return

        self.current_state = RobotState.SPINNING_BACK
        self.set_chassis_mode(ChassisMode.HOLD, "扫码完成，串口模式下等待电控反向自旋回原朝向")
        self.get_logger().info(
            "扫码阶段结束，已等待电控在命令3后自旋回原朝向；"
            "ROS 不再发布反向自旋底盘模式，收到命令3完成回包后再发布下一个导航点"
        )

    def start_final_spin(self):
        self.reset_spin_tracking()
        self.current_state = RobotState.WAITING_FINAL_RESULT
        self.set_chassis_mode(ChassisMode.HOLD, "到达最终点，等待电控最终流程完成")
        self.send_serial("6")
        self.get_logger().info("最终点已到达，已发送命令6，等待电控完成回包后发布 /mode=2")

    def finish_spin(self):
        spin_deg = math.degrees(self.spin_accumulated_yaw)
        if self.current_state == RobotState.SPINNING_FORWARD:
            self.reset_spin_tracking()
            self.set_chassis_mode(ChassisMode.HOLD, "正向自旋完成，驻停等待 TF 对位")
            self.current_state = RobotState.ALIGNING_TF
            self.get_logger().info(f"正向自旋完成，累计角度 {spin_deg:.1f} deg | 状态 -> {self.current_state.name}")
            return

        if self.current_state == RobotState.SPINNING_BACK:
            reason = self.pending_post_spin_reason or "反向自旋完成"
            force_final = self.pending_post_spin_force_final
            send_cmd3_after_spin = self.pending_post_spin_send_cmd3
            self.pending_post_spin_reason = None
            self.pending_post_spin_force_final = False
            self.pending_post_spin_send_cmd3 = True
            self.reset_spin_tracking()
            self.set_chassis_mode(ChassisMode.HOLD, "反向自旋完成，准备恢复导航")
            if send_cmd3_after_spin:
                self.send_serial("3")
                self.get_logger().info(f"反向自旋完成，累计角度 {spin_deg:.1f} deg，发送命令3后恢复导航")
            else:
                self.get_logger().info(f"反向自旋完成，累计角度 {spin_deg:.1f} deg，直接恢复导航")
            self.advance_to_next_target(reason, force_final=force_final)
            return

    def handle_spin_completed(self):
        if self.current_state == RobotState.SPINNING_FORWARD:
            self.set_chassis_mode(ChassisMode.HOLD, "电控反馈正向自旋完成，驻停等待 TF 对位")
            self.current_state = RobotState.ALIGNING_TF
            self.get_logger().info(f"收到命令3完成回包，正向自旋完成 | 状态 -> {self.current_state.name}")
            return

        if self.current_state == RobotState.SPINNING_BACK:
            reason = self.pending_post_spin_reason or "反向自旋完成"
            force_final = self.pending_post_spin_force_final
            send_cmd3_after_spin = self.pending_post_spin_send_cmd3
            self.pending_post_spin_reason = None
            self.pending_post_spin_force_final = False
            self.pending_post_spin_send_cmd3 = True
            self.set_chassis_mode(ChassisMode.HOLD, "电控反馈反向自旋完成，准备恢复导航")
            if self.spin_control_mode == "local" and send_cmd3_after_spin:
                self.send_serial("3")
                self.get_logger().info("收到命令3完成回包，反向自旋完成，发送命令3后恢复导航")
            elif self.spin_control_mode == "local":
                self.get_logger().info("收到命令3完成回包，反向自旋完成，直接恢复导航")
            else:
                self.stop_serial("3")
                self.get_logger().info("收到命令3完成回包，电控反向自旋完成，准备恢复导航")
            self.advance_to_next_target(reason, force_final=force_final)
            return

        if self.current_state == RobotState.WAITING_FINAL_RESULT:
            self.stop_serial("6")
            self.set_chassis_mode(ChassisMode.HOLD, "电控反馈最终流程完成，底盘驻停")
            self.current_state = RobotState.FINISHED
            self.external_mode_pub.publish(Int32(data=2))
            self.get_logger().info("收到命令6完成回包，已发布 /mode=2 | 状态 -> FINISHED")
            threading.Timer(2.0, self.final_exit).start()

    def grab_feedback_timer_callback(self):
        with self.lock:
            self.check_grab_feedback_task()

    def odom_callback(self, msg: Odometry):
        with self.lock:
            q = msg.pose.pose.orientation
            yaw = self.quaternion_to_yaw(q.x, q.y, q.z, q.w)
            self.current_yaw = yaw

            if self.spin_control_mode != "local":
                return

            if not self.is_spinning_state():
                return

            if self.maybe_fallback_spin_source_to_odom(yaw):
                return

            if self.spin_source_in_use != "odom":
                return

            self.update_spin_with_yaw(yaw, "ODOM")

    def imu_callback(self, msg: Imu):
        with self.lock:
            now = time.monotonic()
            self.last_imu_rx_time = now

            if self.imu_last_sample_time is None:
                self.imu_last_sample_time = now
                self.imu_integrated_yaw = 0.0
                self.imu_start_frame_locked = True
                self.get_logger().info("已锁定启动时首帧 IMU，作为全局角度零点")
            else:
                dt = now - self.imu_last_sample_time
                self.imu_last_sample_time = now
                if 0.0 < dt <= max(0.5, self.spin_imu_timeout * 2.0):
                    self.imu_integrated_yaw += msg.angular_velocity.z * dt

            if self.spin_control_mode != "local":
                return

            if not self.is_spinning_state():
                return

            if self.spin_source_in_use != "imu":
                return

            self.update_spin_with_imu()

    # ==================== TF 对位 ====================
    def tf_check_loop(self):
        with self.lock:
            # 只有在 ALIGNING_TF 状态下才处理 TF
            if self.current_state != RobotState.ALIGNING_TF:
                return
            try:
                now = self.get_clock().now()
                t = self.tf_buffer.lookup_transform(
                    self.reference_frame, self.target_tag_frame,
                    rclpy.time.Time(), timeout=rclpy.duration.Duration(seconds=0.2)
                )
                transform_age = (now - rclpy.time.Time.from_msg(t.header.stamp)).nanoseconds / 1e9
                if transform_age > 0.6:
                    return
                tag_y = t.transform.translation.y
                align_error = tag_y - self.align_target_y
                if abs(align_error) < self.align_tolerance:
                    self.send_serial("2")
                    self.current_state = RobotState.WAITING_BARCODE
                    self.get_logger().info(
                        f"TF 对位成功! tag_y={tag_y:.3f}m target_y={self.align_target_y:.3f}m "
                        f"error={align_error:.3f}m | 状态 -> {self.current_state.name}"
                    )
            except TransformException:
                pass

    def try_handle_detecting_state(self, trigger_source: str, allow_skip_on_false: bool = False):
        if self.current_state != RobotState.DETECTING:
            return

        if self.point_index >= len(self.grab_points):
            return

        if self.object_present:
            if self.grab_count >= self.max_grab_count:
                return
            if not self.depth_sample_received:
                self.get_logger().debug(
                    f"{trigger_source}: 已识别到物体，但尚未收到深度，继续等待 /object_depth"
                )
                return
            self.pre_grab_depth = self.current_depth
            self.send_serial("1")
            self.grab_count += 1
            self.current_state = RobotState.WAITING_GRAB_RESULT
            self.checking_grab_feedback = True
            self.grab_start_time = time.time()
            self.get_logger().info(
                f"检测到物体（触发源: {trigger_source}），发送命令1开始抓取 | "
                f"物体深度={self.pre_grab_depth:.3f}m | 状态 -> {self.current_state.name}"
            )
            return

        if not allow_skip_on_false:
            return

        current_index = self.point_index
        if self.point_index < len(self.grab_points) - 1:
            next_index = current_index + 1
            self.navigate_to_grab_point(next_index)
            self.get_logger().info(
                f"⚠️ 抓取点 {current_index} 未检测到物体，直接前往抓取点 {next_index} | 状态 -> {self.current_state.name}"
            )
        else:
            self.navigate_to_final_point()
            self.get_logger().info(
                f"⚠️ 抓取点 {current_index} 未检测到物体，直接前往最终点 | 状态 -> {self.current_state.name}"
            )

    def object_depth_callback(self, msg: Float32):
        with self.lock:
            self.current_depth = msg.data
            self.depth_sample_received = True
            self.object_depth_rx_count += 1
            if self.object_depth_rx_count == 1:
                self.get_logger().info(f"已收到首帧 /object_depth: {self.current_depth:.3f}m")
            self.try_handle_detecting_state("/object_depth")

    def object_status_callback(self, msg: Bool):
        with self.lock:
            self.object_present = msg.data
            self.object_detected_rx_count += 1
            if self.object_detected_rx_count == 1:
                self.get_logger().info(f"已收到首帧 /object_detected: {self.object_present}")
            self.try_handle_detecting_state("/object_detected", allow_skip_on_false=True)

    def check_grab_feedback_task(self):
        """独立于主状态机的抓取反馈检测逻辑"""
        if not self.checking_grab_feedback:
            return
            
        elapsed = time.time() - self.grab_start_time
        if elapsed < self.grab_check_delay:
            self.get_logger().debug(f"[抓取反馈] 等待中... {elapsed:.1f}s/{self.grab_check_delay}s")
            return

        if self.object_present and abs(self.current_depth - self.pre_grab_depth) < self.grab_depth_tolerance:
            self.get_logger().info(f" 物体还在 | 原深度:{self.pre_grab_depth:.3f} | 现深度:{self.current_depth:.3f} | 差值:{abs(self.current_depth - self.pre_grab_depth):.3f}")
            self.get_logger().warn("⚠️ 判定抓取失败，结束当前抓取流程并跳过当前抓取点")
            if self.active_serial_cmd == "1":
                self.stop_serial("1")
            self.send_serial("5")
            self.grab_count = max(0, self.grab_count - 1)
            self.checking_grab_feedback = False
            self.advance_to_next_target("抓取失败，跳过当前抓取点")
        else:
            self.checking_grab_feedback = False
            self.navigate_to_shift_point(self.point_index)
            self.get_logger().info(
                f"物体已被拿走（颜色或深度已变化），先前往平移点 {self.point_index}，到达后切入自旋模式"
            )

    def barcode_callback(self, msg: String):
        with self.lock:
            barcode_data = msg.data.strip()

            # TF 还在对齐时，如果提前扫到码，也直接接收处理
            if self.current_state not in (RobotState.ALIGNING_TF, RobotState.WAITING_BARCODE):
                return

            if barcode_data == "200":
                if self.special_barcode_triggered:
                    return
                self.special_barcode_triggered = True
                if self.active_serial_cmd == "2":
                    self.stop_serial("2")
                self.send_serial("3")
                self.get_logger().info("收到特殊二维码 200，已发送命令3，等待电控反向自旋回正后执行最终流程")
                self.start_spin_back("特殊二维码 200，直接前往最终点", force_final=True)
                return

            if barcode_data == "100":
                self.send_serial("3")
                self.get_logger().info("收到二维码 100，已发送命令3，准备先反向自旋回正再前往下一个抓取点")
                self.start_spin_back("普通二维码 100，扫码流程完成", send_cmd3_after_spin=False)

    def advance_to_next_target(self, reason: str, force_final: bool = False):
        self.checking_grab_feedback = False
        self.pending_post_spin_reason = None
        self.pending_post_spin_force_final = False
        self.pending_post_spin_send_cmd3 = True
        if force_final or self.point_index == len(self.grab_points) - 1 or self.grab_count >= self.max_grab_count:
            self.navigate_to_final_point()
            self.get_logger().info(f"{reason}，准备前往最终点 | 状态 -> {self.current_state.name}")
            return

        next_index = self.point_index + 1
        self.navigate_to_grab_point(next_index)
        self.get_logger().info(f"{reason}，准备前往抓取点 {next_index} | 状态 -> {self.current_state.name}")

    def publish_goal(self, goal_point: Point3d, goal_name: str):
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "odom"
        msg.pose.position.x = goal_point.x
        msg.pose.position.y = goal_point.y
        msg.pose.position.z = goal_point.z
        cy = math.cos(goal_point.yaw * 0.5)
        sy = math.sin(goal_point.yaw * 0.5)
        msg.pose.orientation.z = sy
        msg.pose.orientation.w = cy
        self.goal_pub.publish(msg)
        self.get_logger().info(f"已发布{goal_name}: ({goal_point.x}, {goal_point.y}, {goal_point.z}, {goal_point.yaw:.2f})")

    def nav_callback(self, msg: Bool):
        with self.lock:
            if not msg.data:
                return

            nav_target = self.active_nav_target
            nav_index = self.active_nav_index
            if nav_target == NavTarget.NONE:
                return

            self.active_nav_target = NavTarget.NONE
            self.active_nav_index = None

            if nav_target == NavTarget.SHIFT_POINT:
                self.start_spin_mode(nav_index)
                return

            if nav_target == NavTarget.GRAB_POINT and self.active_serial_cmd == "3":
                self.stop_serial("3")

            if nav_target == NavTarget.FINAL_POINT:
                if self.active_serial_cmd == "3":
                    self.stop_serial("3")
                self.start_final_spin()
                return

            if nav_target != NavTarget.GRAB_POINT:
                return

            self.current_state = RobotState.STABILIZING
            threading.Timer(self.stabilization_time, self.finish_stabilization).start()
            self.get_logger().info(f"到达抓取点 {nav_index}，开始稳定等待 {self.stabilization_time} 秒... | 状态 -> {self.current_state.name}")

    def finish_stabilization(self):
        with self.lock:
            if self.current_state == RobotState.STABILIZING:
                self.current_state = RobotState.DETECTING
                self.get_logger().info(f"抓取点 {self.point_index} 已稳定，现在开始正常检测颜色+深度 | 状态 -> {self.current_state.name}")
                if self.object_detected_rx_count == 0 or self.object_depth_rx_count == 0:
                    self.log_sensor_topic_debug("进入 DETECTING 但视觉消息未齐")
                self.try_handle_detecting_state("进入 DETECTING")

    def final_exit(self):
        self.get_logger().info("最终点流程结束，准备退出节点")
        time.sleep(0.5)
        self.stop_node()

    def send_serial(self, cmd: str):
        if cmd not in SERIAL_COMMANDS:
            self.get_logger().warn(f"未知串口命令: {cmd}")
            return
        with self.lock:
            self.active_serial_cmd = cmd
        self._write_serial_frame(cmd)

    def stop_serial(self, cmd: str | None = None):
        with self.lock:
            if self.active_serial_cmd is None:
                return
            if cmd is not None and self.active_serial_cmd != cmd:
                return
            self.get_logger().info(f"清除活动串口命令记录 {self.active_serial_cmd}")
            self.active_serial_cmd = None

    def _write_serial_frame(self, cmd: str):
        if not (self.serial and self.serial.is_open):
            self.get_logger().warn(f"串口不可用，跳过指令: {cmd}")
            return
        command_cfg = SERIAL_COMMANDS.get(cmd)
        if command_cfg is None:
            self.get_logger().warn(f"未知串口命令: {cmd}")
            return

        frame = build_vision_frame(
            command_cfg["region"],
            command_cfg["mode"],
            command_cfg["need_return"],
            command_cfg["data"],
        )
        try:
            self.serial.reset_output_buffer()
            self.serial.write(frame)
            self.serial.flush()
            self.get_logger().info(f"➡ 串口命令 {cmd} 单次发送成功")
        except Exception as e:
            self.get_logger().error(f"发送失败: {e}")

    def listen_stm32_data(self):
        while self.node_running:
            if self.serial and self.serial.is_open:
                try:
                    recv_data = self.serial.read(self.serial.in_waiting or 1)
                    if recv_data:
                        self.serial_rx_buffer.extend(recv_data)
                        frame_hex = " ".join(f"{byte:02X}" for byte in recv_data)
                        self.get_logger().info(f"⬅ 收到串口原始数据: {frame_hex}")
                        self.process_serial_frames()
                    else:
                        time.sleep(0.01)
                except Exception as e:
                    self.get_logger().error(f"串口读取失败: {e}")
                    time.sleep(0.01)
            else:
                time.sleep(1.0)

    def process_serial_frames(self):
        while True:
            while self.serial_rx_buffer and self.serial_rx_buffer[0] != FRAME_HEADER:
                dropped = self.serial_rx_buffer.pop(0)
                self.get_logger().warn(f"丢弃无效帧头字节: 0x{dropped:02X}")

            if len(self.serial_rx_buffer) < FRAME_LENGTH:
                return

            frame = bytes(self.serial_rx_buffer[:FRAME_LENGTH])
            if frame[-1] != FRAME_TAIL:
                dropped = self.serial_rx_buffer.pop(0)
                self.get_logger().warn(f"帧尾不匹配，丢弃当前帧头字节: 0x{dropped:02X}")
                continue

            del self.serial_rx_buffer[:FRAME_LENGTH]
            parsed = parse_vision_frame(frame)
            if parsed is None:
                self.get_logger().warn(f"收到无法解析的帧: {frame.hex()}")
                continue

            if not parsed["crc_ok"]:
                self.get_logger().warn(f"收到 CRC 校验失败的帧: {parsed['raw']}")
                continue

            self.handle_serial_frame(parsed)

    def handle_serial_frame(self, frame: dict):
        self.get_logger().info(
            "⬅ 收到有效回包: "
            f"region={frame['region']} mode={frame['mode']} "
            f"task_complete={frame['task_complete']} data={frame['data']}"
        )

        with self.lock:
            if (
                self.spin_control_mode == "serial4"
                and frame["mode"] == SERIAL_COMMANDS["3"]["mode"]
                and frame["task_complete"] == 1
            ):
                if self.current_state == RobotState.SPINNING_BACK:
                    self.stop_serial("3")
                else:
                    self.stop_serial("4")
                self.handle_spin_completed()
                return

            if (
                frame["mode"] == SERIAL_COMMANDS["6"]["mode"]
                and frame["task_complete"] == 1
                and self.current_state == RobotState.WAITING_FINAL_RESULT
            ):
                self.handle_spin_completed()
                return

            active_cmd = self.active_serial_cmd
            if active_cmd is not None:
                active_mode = SERIAL_COMMANDS[active_cmd]["mode"]
                if frame["mode"] == active_mode and frame["task_complete"] == 1:
                    self.stop_serial(active_cmd)

    def stop_node(self):
        self.node_running = False
        self.stop_serial()
        time.sleep(1.0)
        if self.serial and self.serial.is_open:
            self.serial.close()
        sys.exit(0)

    def destroy_node(self):
        self.node_running = False
        self.stop_serial()
        super().destroy_node()

    @staticmethod
    def quaternion_to_yaw(x: float, y: float, z: float, w: float) -> float:
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        return math.atan2(siny_cosp, cosy_cosp)

    @staticmethod
    def normalize_angle(angle: float) -> float:
        return math.atan2(math.sin(angle), math.cos(angle))


def main():
    rclpy.init(args=sys.argv)
    node = None
    try:
        node = R2_mode1()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
