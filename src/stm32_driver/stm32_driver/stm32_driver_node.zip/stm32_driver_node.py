#!/usr/bin/env python3
import serial
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import struct
from nav_msgs.msg import Odometry
from std_msgs.msg import Int32
import math
from enum import IntEnum

CHASSIS_MODE_TOPIC = "/chassis_mode"


class ChassisMode(IntEnum):
    NAVIGATION = 0
    SPIN_FORWARD = 1
    HOLD = 2
    SPIN_BACKWARD = 3
    CONTACT_APPROACH = 4


class STM32Driver(Node):
    def __init__(self):
        super().__init__('stm32_driver')
        #!/usr/bin/env python3

        self.PITCH_TARGET_1 = math.radians(17)   
        self.PITCH_TARGET_2 = math.radians(-17) 
        self.PITCH_TOLERANCE = math.radians(1)   
        self.current_compensation = 0.0
        self.K_COMPENSATION = 7.0
        self.MAX_COMPENSATION = 2.0      
        
        self.MIN_UPHILL_SPEED = 1.4 
        
        # 加速响应要快 (Attack)
        self.STEP_UP = 0.8               
        # 减速响应要适中 (Release)
        self.STEP_DOWN = 0.15
        # 1. 配置串口参数（与STM32一致）
        self.declare_parameter('serial_port', '/dev/ttyUSB2') 
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('timeout', 1.0)
        self.declare_parameter('spin_angular_speed', 1.5)
        self.declare_parameter('override_frequency', 20.0)
        self.declare_parameter('contact_cmd_vel_topic', '/contact_cmd_vel')
        self.angle=[0,0,0]
        serial_port = self.get_parameter('serial_port').value
        baudrate = self.get_parameter('baudrate').value
        timeout = self.get_parameter('timeout').value
        self.spin_angular_speed = self.get_parameter('spin_angular_speed').value
        self.contact_cmd_vel_topic = self.get_parameter('contact_cmd_vel_topic').value
        override_frequency = self.get_parameter('override_frequency').value
        override_period = 1.0 / max(1.0, override_frequency)
        self.count=0
        self.current_mode = ChassisMode.NAVIGATION
        self.serial = None
        # 2. 初始化串口
        try:
            self.serial = serial.Serial(port=serial_port, baudrate=baudrate, timeout=timeout)
            self.get_logger().info(f'已连接STM32: {serial_port}')
        except Exception as e:
            self.get_logger().error(f'串口打开失败: {e}')
            return
        self.odom_sub =self.create_subscription(Odometry,"/Odometry",self.odom_callback,10)
        self.mode_sub = self.create_subscription(Int32, CHASSIS_MODE_TOPIC, self.mode_callback, 10)
        self.cmd_vel_sub = self.create_subscription(
            Twist, 'cmd_vel', self.cmd_vel_callback, 10 # 队列大小10
        )
        self.contact_cmd_vel_sub = self.create_subscription(
            Twist, self.contact_cmd_vel_topic, self.contact_cmd_vel_callback, 10
        )
        self.override_timer = self.create_timer(override_period, self.override_control_callback)
    def odom_callback(self,msg:Odometry):
        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w
        roll, pitch, yaw = self.quaternion_to_euler(qx, qy, qz, qw)
        self.angle=[roll,pitch,yaw]
        
        
    def quaternion_to_euler(self,x, y, z, w):
   
    # 计算滚转角（roll）
        sinr_cosp = 2 * (w * x + y * z)
        cosr_cosp = 1 - 2 * (x * x + y * y)
        roll = math.atan2(sinr_cosp, cosr_cosp)

    # 计算俯仰角（pitch）
        sinp = 2 * (w * y - z * x)
        if abs(sinp) >= 1:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)

    # 计算偏航角（yaw）
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw = math.atan2(siny_cosp, cosy_cosp)

        return roll, pitch, yaw

    def mode_callback(self, msg: Int32):
        try:
            new_mode = ChassisMode(msg.data)
        except ValueError:
            self.get_logger().warn(f'收到未知底盘模式: {msg.data}')
            return

        if new_mode == self.current_mode:
            return

        self.current_mode = new_mode
        self.get_logger().info(f'底盘模式切换为: {new_mode.name}')

        if new_mode == ChassisMode.SPIN_FORWARD:
            self.send_binary_command(0.0, 0.0, self.spin_angular_speed, 0, 0, log_command=False)
        elif new_mode == ChassisMode.SPIN_BACKWARD:
            self.send_binary_command(0.0, 0.0, -self.spin_angular_speed, 0, 0, log_command=False)
        elif new_mode == ChassisMode.HOLD:
            self.send_binary_command(0.0, 0.0, 0.0, 0, 0, log_command=False)
        elif new_mode == ChassisMode.CONTACT_APPROACH:
            self.send_binary_command(0.0, 0.0, 0.0, 0, 0, log_command=False)
        else:
            self.send_binary_command(0.0, 0.0, 0.0, 0, 0, log_command=False)

    def override_control_callback(self):
        if self.current_mode == ChassisMode.SPIN_FORWARD:
            self.send_binary_command(0.0, 0.0, self.spin_angular_speed, 0, 0, log_command=False)
        elif self.current_mode == ChassisMode.SPIN_BACKWARD:
            self.send_binary_command(0.0, 0.0, -self.spin_angular_speed, 0, 0, log_command=False)
        elif self.current_mode == ChassisMode.HOLD:
            self.send_binary_command(0.0, 0.0, 0.0, 0, 0, log_command=False)
        
    def contact_cmd_vel_callback(self, msg: Twist):
        if self.current_mode != ChassisMode.CONTACT_APPROACH:
            return

        linear_x = msg.linear.x
        self.send_binary_command(linear_x, 0.0, 0.0, 0, 0)
        self.get_logger().info(f'contact_vx:{linear_x:.2f},vy:0.00,vz:0.0')

    def cmd_vel_callback(self, msg:Twist):
        if self.current_mode != ChassisMode.NAVIGATION:
            return
        # 限制速度范围（避免STM32电机过载）
        linear_x=msg.linear.x
        target_compensation = 0.0
        slope_angle_rad = -self.angle[1] 
        angular_z = max(min(msg.angular.z, 3.14), -3.14) # 角速度范围：-π~π rad/s
        linear_y = msg.linear.y
        K_compensation = 5.0
        self.get_logger().info(f"{self.angle[1]}")
        compensation = 0.0
        if -self.angle[1]>math.radians(1.1):
            compensation = K_compensation * math.sin(-self.angle[1])
            
            compensation = min(compensation, 1.2)
            linear_x+=compensation
            self.get_logger().info(f'上坡中: 角度={math.degrees(-self.angle[1]):.1f}°, 额外补油={compensation:.2f}')
        if slope_angle_rad > math.radians(2.0):
            
            slope_comp = self.K_COMPENSATION * math.sin(slope_angle_rad)
            
            
            speed_gap_comp = self.MIN_UPHILL_SPEED - linear_x
            
            #  取最大值
            raw_comp = max(slope_comp, speed_gap_comp)
            
            raw_comp = max(raw_comp, 0.7)
            
            # 封顶
            target_compensation = min(raw_comp, self.MAX_COMPENSATION)
            
        elif slope_angle_rad < math.radians(-2.0):
            target_compensation = 0.0 

        if target_compensation > self.current_compensation:
            self.current_compensation = min(self.current_compensation + self.STEP_UP, target_compensation)
        elif target_compensation < self.current_compensation:
            self.current_compensation = max(self.current_compensation - self.STEP_DOWN, target_compensation)
 
       # --- 合成指令 ---
        linear_x +=self.current_compensation
        linear_x=min(1.25,linear_x)
        mode=0
        self.send_binary_command(linear_x, linear_y, angular_z, 0, mode)
        self.get_logger().info(f'vx:{linear_x:.2f},vy:{linear_y:.2f},vz:{angular_z}')

    def send_binary_command(self, vx, vy, vw, flag, mode, log_command=True):
        """发送二进制控制协议到STM32"""
        if self.serial is None or not self.serial.is_open:
            return
            
        try:
            # 1. 浮点数转换为整型 (m/s -> mm/s, rad/s -> mrad/s)
            vx_int = int(vx * 1000)
            vy_int = int(vy * 1000)
            vw_int = int(vw * 10)
            flag = int(flag)
            mode = int(mode)
            reserved = 0  # 保留字，当前固定填 0

            if not 0 <= flag <= 0xFF:
                raise ValueError(f'flag 超出 1 字节范围: {flag}')
            if not 0 <= mode <= 0xFF:
                raise ValueError(f'mode 超出 1 字节范围: {mode}')
            
            # 2. 打包前 10 个字节：SOF + Vx + Vy + Vw + Flag + Reserved + Mode
            # '<' 表示小端模式(STM32常用)
            frame_head = struct.pack('<B h h h B B B', 
                                     0xA5,       # SOF (帧头，1字节)
                                     vx_int,     # Vx (2字节)
                                     vy_int,     # Vy (2字节)
                                     vw_int,     # Vw (2字节)
                                     flag,       # Flag (1字节)
                                     reserved,   # Reserved (1字节)
                                     mode)       # Mode (1字节)
            
            # 3. 提取纯数据部分进行 CRC 校验
            # 使用 [1:] 跳过第0个字节（即 0xA5 帧头），只对后面的 9 个字节的数据进行校验
            data_to_crc = frame_head[1:]
            crc = self.calc_crc8(data_to_crc)
            
            # 4. 拼接完整数据帧 (追加 CRC 和 0xFF 帧尾)
            full_frame = frame_head + struct.pack('<B B', crc, 0xFF)
            
            # 5. 通过串口发送字节流
            if log_command:
                self.get_logger().info(f'命令发送成功: flag={flag}, mode={mode}')
            
            self.serial.write(full_frame)
            
        except Exception as e:
            self.get_logger().error(f'二进制命令发送失败: {e}')
      # ================== CRC-8 计算函数 ==================
    def calc_crc8(self, data: bytes, poly: int = 0x07, init_value: int = 0x00) -> int:
        """
        计算标准 CRC-8
        :param data: 需要计算的字节数据
        :param poly: 多项式 (标准通常为 0x07)
        :param init_value: 初始值
        :return: 计算出的 CRC-8 校验值 (0-255)
        """
        crc = init_value
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x80:
                    crc = (crc << 1) ^ poly
                else:
                    crc <<= 1
                crc &= 0xFF  # 确保始终是8位
        return crc
def main():
    rclpy.init() 
    node = STM32Driver() # 创建节点
    try:
        rclpy.spin(node) # 自旋节点（持续运行）
    except KeyboardInterrupt:
        pass
    finally:
        if node.serial and node.serial.is_open:
            node.serial.close() # 关闭串口
        node.destroy_node() # 销毁节点
        rclpy.shutdown() # 关闭ROS2上下文

if __name__ == '__main__':
    main()
        
